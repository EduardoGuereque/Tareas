import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Ventana extends JFrame {
    private JTextField usuario;
    private JPasswordField contrasena;
    private JButton login;
    
    private JTextField usuario2;
    private JTextArea bio;
    private JPasswordField contrasena2;
    private JButton login2;
    private JCheckBox dulce, salado, saludable;
    private ButtonGroup termino = new ButtonGroup();
    private JRadioButton aceptar;
    private JRadioButton rechazar;
    private JComboBox lugar;
    private JMenuBar menuBar;
    private JMenu mnNewMenu;
    private JMenuItem mntmNewMenuItem_1;
    private JMenu mnNewMenu_1;
    private JMenu mnNewMenu_2;
    private JMenuItem mntmNewMenuItem;
    private JMenuItem mntmNewMenuItem_2;
    private JMenuItem mntmNewMenuItem_3;
    private JMenuItem mntmNewMenuItem_4;
    private JMenuItem mntmNewMenuItem_5;
    private JMenuItem mntmNewMenuItem_6;
    private JMenuItem mntmNewMenuItem_7;
    private JMenuItem mntmNewMenuItem_8;

    public Ventana() {
        setTitle("Iniciar Sesión");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.setLocation(1, 1);
        
        panel.add(new JLabel("Usuario:"));
        usuario = new JTextField();
        panel.add(usuario);
        
        panel.add(new JLabel("Contraseña:"));
        contrasena = new JPasswordField();
        panel.add(contrasena);
        
        login = new JButton("Iniciar Sesión");
        panel.add(new JLabel()); // una etiqueta invisible q puse para que el boton de iniciar sesion quede debajo mejor alineadp
        panel.add(login);

        getContentPane().add(panel);
        
        
        
        setTitle("Registro");
        setSize(400, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        
        JPanel panel2 = new JPanel(new GridLayout(12, 1));
        panel2.setLocation(400, 0);
        
        
        JLabel etiqueta1 = new JLabel("REGISTRO", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);
        panel2.add(etiqueta1);
        
        panel2.add(new JLabel("Nombre de usuario:", SwingConstants.CENTER));
        usuario2 = new JTextField();
       
        panel2.add(usuario2);
        
        panel2.add(new JLabel("BIO:", SwingConstants.CENTER));
        bio = new JTextArea();
		
        panel2.add(bio);
        
        panel2.add(new JLabel("PREFERENCIAS", SwingConstants.CENTER));
                
        JPanel preferencias = new JPanel(new GridLayout(1, 3));
        dulce = new JCheckBox("Dulce");
        salado = new JCheckBox("Salado");
        saludable = new JCheckBox("Saludable");
        preferencias.add(dulce);
        preferencias.add(salado);
        preferencias.add(saludable);

        panel2.add(preferencias);
        
        panel2.add(new JLabel("TERMINOS Y CONDICIONES", SwingConstants.CENTER));
        aceptar = new JRadioButton("ACEPTAR");
        rechazar = new JRadioButton("RECHAZAR");
        termino.add(aceptar);
        termino.add(rechazar);
        JPanel condiciones = new JPanel(new GridLayout(1, 2));
        condiciones.add(aceptar);
        condiciones.add(rechazar);
        panel2.add(condiciones);
        
        String[] lugares = {"Elegir una ubicación", "La Fuente", "Camino Real", "Centro", "Miramar"};
        JComboBox<String> lugar = new JComboBox<>(lugares);
        panel2.add(lugar);
        
        login2 = new JButton("Iniciar Sesión"); //boton
        login2.addActionListener(new ActionListener() {
        	
        	public void actionPerformed(ActionEvent e) {
                
                		
        		String textoTF = usuario2.getText();
        		if(textoTF.equals("")) {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
        	               
                String textoTA = bio.getText();
                if(textoTA.equals("")) {
        			bio.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			bio.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
                
                if (aceptar.isSelected() && rechazar.isSelected()==false) {
                	aceptar.setBorder(BorderFactory.createLineBorder(Color.GREEN,3));
                } else {
                	aceptar.setBorder(BorderFactory.createLineBorder(Color.RED,3));
                }
                }
        		
        	
        });
        login2.setBackground(new Color(204, 255, 255));
        login2.setForeground(Color.BLACK);
        login2.setFont(new Font("Arial", Font.BOLD, 16));
        panel2.add(login2);
        
        panel2.add(new JLabel(" ", SwingConstants.CENTER));

        getContentPane().add(panel2);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
    }
    
    public void manager(String target) {
		this.getContentPane().removeAll();
		if(target.equals("Registro")) {
			getContentPane().add(this.registro());
		}
		if(target.equals("Login")) {
			getContentPane().add(this.login());
		}
		if(target.equals("Recuperar")) {
			getContentPane().add(this.recuperar());
		}
		if(target.equals("Alta")) {
			getContentPane().add(this.alta());
		}
		if(target.equals("Baja")) {
			getContentPane().add(this.baja());
		}
		if(target.equals("Consultar")) {
			getContentPane().add(this.consultar());
		}
		if(target.equals("Crear")) {
			getContentPane().add(this.crear());
		}
		if(target.equals("Acceder")) {
			getContentPane().add(this.acceder());
		}
		if(target.equals("Contrasena")) {
			getContentPane().add(this.contrasena());
		}
		
		this.repaint();
		this.revalidate();
		
	}
    
    public JPanel login() {
        this.setTitle("Login");
        this.setSize(400, 200);
        this.setResizable(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BorderLayout());

        JLabel etiqueta1 = new JLabel("Login", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);

        panel.add(etiqueta1, BorderLayout.NORTH);
        getContentPane().add(panel);
		return panel;

    }
    
    public JPanel registro() {
        this.setTitle("Registro");
        this.setSize(400, 200);
        this.setResizable(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BorderLayout());

        JLabel etiqueta1 = new JLabel("Registro", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);

        panel.add(etiqueta1, BorderLayout.NORTH);
        getContentPane().add(panel);
		return panel;
    }
    
    public JPanel recuperar() {
        this.setTitle("Recuperar");
        this.setSize(400, 200);
        this.setResizable(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BorderLayout());

        JLabel etiqueta1 = new JLabel("Recuperar", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);

        panel.add(etiqueta1, BorderLayout.NORTH);
        getContentPane().add(panel);
		return panel;
    }
    
    public JPanel alta() {
        this.setTitle("Alta");
        this.setSize(400, 200);
        this.setResizable(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BorderLayout());

        JLabel etiqueta1 = new JLabel("Alta", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);

        panel.add(etiqueta1, BorderLayout.NORTH);
        getContentPane().add(panel);
		return panel;
    }
    
    public JPanel baja() {
        this.setTitle("Baja");
        this.setSize(400, 200);
        this.setResizable(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BorderLayout());

        JLabel etiqueta1 = new JLabel("Baja", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);

        panel.add(etiqueta1, BorderLayout.NORTH);
        getContentPane().add(panel);
		return panel;
    }
    
    public JPanel consultar() {
        this.setTitle("Consultar");
        this.setSize(400, 200);
        this.setResizable(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BorderLayout());

        JLabel etiqueta1 = new JLabel("Consultar", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);

        panel.add(etiqueta1, BorderLayout.NORTH);
        getContentPane().add(panel);
		return panel;
    }
    
    public JPanel crear() {
        this.setTitle("Crear usuario");
        this.setSize(400, 200);
        this.setResizable(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BorderLayout());

        JLabel etiqueta1 = new JLabel("Crear usuario", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);

        panel.add(etiqueta1, BorderLayout.NORTH);
        getContentPane().add(panel);
		return panel;
    }
    
    public JPanel acceder() {
        this.setTitle("Acceder");
        this.setSize(400, 200);
        this.setResizable(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BorderLayout());

        JLabel etiqueta1 = new JLabel("Acceder", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);

        panel.add(etiqueta1, BorderLayout.NORTH);
        getContentPane().add(panel);
		return panel;
    }
    
    public JPanel contrasena() {
        this.setTitle("Contraseña");
        this.setSize(400, 200);
        this.setResizable(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BorderLayout());

        JLabel etiqueta1 = new JLabel("Contraseña", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);

        panel.add(etiqueta1, BorderLayout.NORTH);
        getContentPane().add(panel);
		return panel;
    }

}
