import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Tictac {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tictac window = new Tictac();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Tictac() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	
	int turno = 2;
	JButton btnNewButton;
	JButton btnNewButton_2;
	JButton btnNewButton_3;
	JButton btnNewButton_4;
	JButton btnNewButton_5;
	JButton btnNewButton_6;
	JButton btnNewButton_7;
	JButton btnNewButton_8;
	JButton btnNewButton_9;
	private JPanel panel_1;
	private JPanel panel_1_1;
	private JPanel panel_1_1_1;
	int mono = 0, raton = 0, empate = 0;
	String player;
	JLabel lblNewLabel_1 = new JLabel("");
	JLabel lblNewLabel_1_1 = new JLabel("");
	JLabel lblNewLabel_1_1_1 = new JLabel("");
	
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 650, 650);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(0, 3, 4, 3));
		
		btnNewButton = new JButton("");
		btnNewButton.setFont(new Font("Trebuchet MS", Font.BOLD, 3));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(turno%2==0) {
					player = "X";
					btnNewButton.setText(player);
					btnNewButton.setIcon(new ImageIcon("src/monkey.png"));
					turno++;
				}
				else {
					player = "O";
					btnNewButton.setText(player);
					btnNewButton.setIcon(new ImageIcon("src/mosso.png"));
					turno++;
				}
				btnNewButton.setEnabled(false);
				Validar();
					
			}
		});
		panel.add(btnNewButton);
		
		
		btnNewButton_2 = new JButton("");
		btnNewButton_2.setFont(new Font("Trebuchet MS", Font.BOLD, 3));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(turno%2==0) {
					player = "X";
					btnNewButton_2.setText(player);
					btnNewButton_2.setIcon(new ImageIcon("src/monkey.png"));
					turno++;
				}
				else {
					player = "O";
					btnNewButton_2.setText(player);
					btnNewButton_2.setIcon(new ImageIcon("src/mosso.png"));
					turno++;
				}
				btnNewButton_2.setEnabled(false);
				Validar();
			}
			
		});
		panel.add(btnNewButton_2);
		
		
		btnNewButton_3 = new JButton("");
		btnNewButton_3.setFont(new Font("Trebuchet MS", Font.BOLD, 3));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(turno%2==0) {
					player = "X";
					btnNewButton_3.setText(player);
					btnNewButton_3.setIcon(new ImageIcon("src/monkey.png"));
					turno++;
				}
				else {
					player = "O";
					btnNewButton_3.setText(player);
					btnNewButton_3.setIcon(new ImageIcon("src/mosso.png"));
					turno++;
				}
				btnNewButton_3.setEnabled(false);
				Validar();
			}
		});
		panel.add(btnNewButton_3);
		
		
		btnNewButton_4 = new JButton("");
		btnNewButton_4.setFont(new Font("Trebuchet MS", Font.BOLD, 3));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(turno%2==0) {
					player = "X";
					btnNewButton_4.setText(player);
					btnNewButton_4.setIcon(new ImageIcon("src/monkey.png"));
					turno++;
				}
				else {
					player = "O";
					btnNewButton_4.setText(player);
					btnNewButton_4.setIcon(new ImageIcon("src/mosso.png"));
					turno++;
				}
				btnNewButton_4.setEnabled(false);
				Validar();
			}
		});
		panel.add(btnNewButton_4);
		
		
		btnNewButton_5 = new JButton("");
		btnNewButton_5.setFont(new Font("Trebuchet MS", Font.BOLD, 3));
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(turno%2==0) {
					player = "X";
					btnNewButton_5.setText(player);
					btnNewButton_5.setIcon(new ImageIcon("src/monkey.png"));
					turno++;
				}
				else {
					player = "O";
					btnNewButton_5.setText(player);
					btnNewButton_5.setIcon(new ImageIcon("src/mosso.png"));
					turno++;
				}
				btnNewButton_5.setEnabled(false);
				Validar();
				
			}
		});
		panel.add(btnNewButton_5);
		
		
		btnNewButton_6 = new JButton("");
		btnNewButton_6.setFont(new Font("Trebuchet MS", Font.BOLD, 3));
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(turno%2==0) {
					player = "X";
					btnNewButton_6.setText(player);
					btnNewButton_6.setIcon(new ImageIcon("src/monkey.png"));
					turno++;
				}
				else {
					player = "O";
					btnNewButton_6.setText(player);
					btnNewButton_6.setIcon(new ImageIcon("src/mosso.png"));
					turno++;
				}
				btnNewButton_6.setEnabled(false);
				Validar();
			}
		});
		panel.add(btnNewButton_6);
		
		btnNewButton_7 = new JButton("");
		btnNewButton_7.setFont(new Font("Trebuchet MS", Font.BOLD, 3));
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(turno%2==0) {
					player = "X";
					btnNewButton_7.setText(player);
					btnNewButton_7.setIcon(new ImageIcon("src/monkey.png"));
					turno++;
				}
				else {
					player = "O";
					btnNewButton_7.setText(player);
					btnNewButton_7.setIcon(new ImageIcon("src/mosso.png"));
					turno++;
				}
				btnNewButton_7.setEnabled(false);
				Validar();
			}
		});
		panel.add(btnNewButton_7);
		
		
		btnNewButton_8 = new JButton("");
		btnNewButton_8.setFont(new Font("Trebuchet MS", Font.BOLD, 3));
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(turno%2==0) {
					player = "X";
					btnNewButton_8.setText(player);
					btnNewButton_8.setIcon(new ImageIcon("src/monkey.png"));
					turno++;
				}
				else {
					player = "O";
					btnNewButton_8.setText(player);
					btnNewButton_8.setIcon(new ImageIcon("src/mosso.png"));
					turno++;
				}
				btnNewButton_8.setEnabled(false);
				Validar();
			}
		});
		panel.add(btnNewButton_8);
		
		
		btnNewButton_9 = new JButton("");
		btnNewButton_9.setFont(new Font("Trebuchet MS", Font.BOLD, 3));
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(turno%2==0) {
					player = "X";
					btnNewButton_9.setText(player);
					btnNewButton_9.setIcon(new ImageIcon("src/monkey.png"));
					turno++;
				}
				else {
					player = "O";
					btnNewButton_9.setText(player);
					btnNewButton_9.setIcon(new ImageIcon("src/mosso.png"));
					turno++;
				}
				btnNewButton_9.setEnabled(false);
				Validar();
			}
		});
		panel.add(btnNewButton_9);
		
		
		
		panel_1 = new JPanel();
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("MONOS");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel.setBounds(38, 11, 133, 22);
		panel_1.add(lblNewLabel);
		
		
		panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel.add(panel_1_1);
		
		JLabel lblRatoncitos = new JLabel("RATONCITOS");
		lblRatoncitos.setHorizontalAlignment(SwingConstants.CENTER);
		lblRatoncitos.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblRatoncitos.setBounds(38, 11, 133, 22);
		panel_1_1.add(lblRatoncitos);
		
		panel_1_1_1 = new JPanel();
		panel_1_1_1.setLayout(null);
		panel.add(panel_1_1_1);
		
		JLabel lblEmpates = new JLabel("EMPATES");
		lblEmpates.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmpates.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblEmpates.setBounds(38, 11, 133, 22);
		panel_1_1_1.add(lblEmpates);
		
		
		
	}
	
	public void puntos() {
		if(player.equals("X")) {
			mono++;
			lblNewLabel_1.setText(String.valueOf(mono));
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 30));
			lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1.setBounds(10, 44, 189, 96);
			panel_1.add(lblNewLabel_1);
		}
		else if(player.equals("O")) {
			raton++;
			lblNewLabel_1_1.setText(String.valueOf(raton));
			lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 30));
			lblNewLabel_1_1.setBounds(10, 44, 189, 96);
			panel_1_1.add(lblNewLabel_1_1);
		}
		else if(!btnNewButton.getText().isEmpty()&& !btnNewButton_2.getText().isEmpty()&&!btnNewButton_3.getText().isEmpty()&&!btnNewButton_4.getText().isEmpty()&&
				!btnNewButton_5.getText().isEmpty()&&!btnNewButton_6.getText().isEmpty()&&!btnNewButton_7.getText().isEmpty()&&!btnNewButton_8.getText().isEmpty()&&!btnNewButton_9.getText().isEmpty()){
			empate++;
			lblNewLabel_1_1_1.setText(String.valueOf(empate));
			lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 30));
			lblNewLabel_1_1_1.setBounds(10, 44, 189, 96);
			panel_1_1_1.add(lblNewLabel_1_1_1);
		}
		panel_1.repaint();
		panel_1_1.repaint();
		panel_1_1_1.repaint();
	}
	
	public void Validar() {
		
		if(btnNewButton.getText().equals(btnNewButton_2.getText()) && btnNewButton_2.getText().equals(btnNewButton_3.getText()) && !btnNewButton.getText().equals("")) {
			
			
			int res = JOptionPane.showConfirmDialog(null, "Desea volver a jugar?",
	                "Reiniciar", JOptionPane.YES_NO_OPTION);
			
			switch (res) {
	        case 0:
	        	puntos();
	            reiniciar();
	            break;
	        case 1:
	        	puntos();
	        	apagar();
	            break;
			}
			
			
		}
		else if(btnNewButton_4.getText().equals(btnNewButton_5.getText()) && btnNewButton_5.getText().equals(btnNewButton_6.getText()) && !btnNewButton_4.getText().equals("")){
			int res = JOptionPane.showConfirmDialog(null, "Desea volver a jugar?",
	                "Reiniciar", JOptionPane.YES_NO_OPTION);
			
			switch (res) {
	        case 0:
	        	puntos();
	            reiniciar();
	            break;
	        case 1:
	        	puntos();
	        	apagar();
	            break;
			}
		}
		else if(btnNewButton_7.getText().equals(btnNewButton_8.getText()) && btnNewButton_8.getText().equals(btnNewButton_9.getText()) && !btnNewButton_7.getText().equals("")){
			int res = JOptionPane.showConfirmDialog(null, "Desea volver a jugar?",
	                "Reiniciar", JOptionPane.YES_NO_OPTION);
			
			switch (res) {
	        case 0:
	        	puntos();
	            reiniciar();
	            break;
	        case 1:
	        	puntos();
	        	apagar();
	            break;
			}
		}
		else if(btnNewButton.getText().equals(btnNewButton_5.getText()) && btnNewButton_5.getText().equals(btnNewButton_9.getText()) && !btnNewButton.getText().equals("")){
			int res = JOptionPane.showConfirmDialog(null, "Desea volver a jugar?",
	                "Reiniciar", JOptionPane.YES_NO_OPTION);
			
			switch (res) {
	        case 0:
	        	puntos();
	            reiniciar();
	            break;
	        case 1:
	        	puntos();
	        	apagar();
	            break;
			}
		}
		else if(btnNewButton_3.getText().equals(btnNewButton_5.getText()) && btnNewButton_5.getText().equals(btnNewButton_7.getText()) && !btnNewButton_3.getText().equals("")){
			int res = JOptionPane.showConfirmDialog(null, "Desea volver a jugar?",
	                "Reiniciar", JOptionPane.YES_NO_OPTION);
			
			switch (res) {
	        case 0:
	        	puntos();
	            reiniciar();
	            break;
	        case 1:
	        	puntos();
	        	apagar();
	            break;
			}
		}
		else if(btnNewButton_3.getText().equals(btnNewButton_6.getText()) && btnNewButton_6.getText().equals(btnNewButton_9.getText()) && !btnNewButton_3.getText().equals("")){
			int res = JOptionPane.showConfirmDialog(null, "Desea volver a jugar?",
	                "Reiniciar", JOptionPane.YES_NO_OPTION);
			
			switch (res) {
	        case 0:
	        	puntos();
	            reiniciar();
	            break;
	        case 1:
	        	puntos();
	        	apagar();
	            break;
			}
		}
		else if(btnNewButton_2.getText().equals(btnNewButton_5.getText()) && btnNewButton_5.getText().equals(btnNewButton_8.getText()) && !btnNewButton_2.getText().equals("")){
			int res = JOptionPane.showConfirmDialog(null, "Desea volver a jugar?",
	                "Reiniciar", JOptionPane.YES_NO_OPTION);
			
			switch (res) {
	        case 0:
	        	puntos();
	            reiniciar();
	            break;
	        case 1:
	        	puntos();
	        	apagar();
	            break;
			}
		}
		else if(btnNewButton.getText().equals(btnNewButton_4.getText()) && btnNewButton_4.getText().equals(btnNewButton_7.getText()) && !btnNewButton.getText().equals("")){
			int res = JOptionPane.showConfirmDialog(null, "Desea volver a jugar?",
	                "Reiniciar", JOptionPane.YES_NO_OPTION);
			
			switch (res) {
	        case 0:
	        	puntos();
	            reiniciar();
	            break;
	        case 1:
	        	puntos();
	        	apagar();
	            break;
			}
		}
		
		else if(!btnNewButton.getText().isEmpty()&& !btnNewButton_2.getText().isEmpty()&&!btnNewButton_3.getText().isEmpty()&&!btnNewButton_4.getText().isEmpty()&&
				!btnNewButton_5.getText().isEmpty()&&!btnNewButton_6.getText().isEmpty()&&!btnNewButton_7.getText().isEmpty()&&!btnNewButton_8.getText().isEmpty()&&!btnNewButton_9.getText().isEmpty()) {
			
			int res = JOptionPane.showConfirmDialog(null, "Desea volver a jugar?",
	                "Reiniciar", JOptionPane.YES_NO_OPTION);
			
			switch (res) {
	        case 0:
	        	puntos();
	            reiniciar();
	            break;
	        case 1:
	        	puntos();
	        	apagar();
	            break;
			}
			
		}
		
	}
	
	public void apagar(){
		btnNewButton.setEnabled(false);
		btnNewButton_2.setEnabled(false);
		btnNewButton_3.setEnabled(false);
		btnNewButton_4.setEnabled(false);
		btnNewButton_5.setEnabled(false);
		btnNewButton_6.setEnabled(false);
		btnNewButton_7.setEnabled(false);
		btnNewButton_8.setEnabled(false);
		btnNewButton_9.setEnabled(false);
	}
	
	public void reiniciar(){
		btnNewButton.setText("");
		btnNewButton.setIcon(null);
		btnNewButton_2.setText("");
		btnNewButton_2.setIcon(null);
		btnNewButton_3.setText("");
		btnNewButton_3.setIcon(null);
		btnNewButton_4.setText("");
		btnNewButton_4.setIcon(null);
		btnNewButton_5.setText("");
		btnNewButton_5.setIcon(null);
		btnNewButton_6.setText("");
		btnNewButton_6.setIcon(null);
		btnNewButton_7.setText("");
		btnNewButton_7.setIcon(null);
		btnNewButton_8.setText("");
		btnNewButton_8.setIcon(null);
		btnNewButton_9.setText("");
		btnNewButton_9.setIcon(null);
		btnNewButton.setEnabled(true);
		btnNewButton_2.setEnabled(true);
		btnNewButton_3.setEnabled(true);
		btnNewButton_4.setEnabled(true);
		btnNewButton_5.setEnabled(true);
		btnNewButton_6.setEnabled(true);
		btnNewButton_7.setEnabled(true);
		btnNewButton_8.setEnabled(true);
		btnNewButton_9.setEnabled(true);
	}
}
