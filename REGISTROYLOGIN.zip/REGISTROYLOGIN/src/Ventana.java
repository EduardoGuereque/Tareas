import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Ventana extends JFrame {
    private JTextField usuario;
    private JPasswordField contrasena;
    private JButton login;
    
    private JTextField usuario2;
    private JTextArea bio;
    private JPasswordField contrasena2;
    private JButton login2;
    private JCheckBox dulce, salado, saludable;
    private ButtonGroup termino = new ButtonGroup();
    private JRadioButton aceptar;
    private JRadioButton rechazar;
    private JComboBox lugar;
    private JMenuBar menuBar;
    private JMenu mnNewMenu;
    private JMenuItem mntmNewMenuItem_1;
    private JMenu mnNewMenu_1;
    private JMenu mnNewMenu_2;
    private JMenuItem mntmNewMenuItem;
    private JMenuItem mntmNewMenuItem_2;
    private JMenuItem mntmNewMenuItem_3;
    private JMenuItem mntmNewMenuItem_4;
    private JMenuItem mntmNewMenuItem_5;
    private JMenuItem mntmNewMenuItem_6;
    private JMenuItem mntmNewMenuItem_7;
    private JMenuItem mntmNewMenuItem_8;
    private JPasswordField passwordField;
    private JCheckBox chckbxNewCheckBox;
    private JTextField NOMBRE;
    private JTable table;
    private JPanel panel;
    private JTable table_1;
    private JLabel lblNewLabel;
    private JLabel lblNewLabel_1;
    private JLabel lblCorreo;
    private JTextField CORREO;
    private JTextArea textArea;

    public Ventana() {

        setTitle("Registro");
        setSize(400, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel2 = new JPanel(new GridLayout(12, 1));
        panel2.setLocation(400, 0);
        
        
        JLabel etiqueta1 = new JLabel("REGISTRO", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);
        panel2.add(etiqueta1);
        
        panel2.add(new JLabel("Nombre de usuario:", SwingConstants.CENTER));
        usuario2 = new JTextField();
       
        panel2.add(usuario2);
        
        panel2.add(new JLabel("BIO:", SwingConstants.CENTER));
        bio = new JTextArea();
		
        panel2.add(bio);
        
        panel2.add(new JLabel("PREFERENCIAS", SwingConstants.CENTER));
                
        JPanel preferencias = new JPanel(new GridLayout(1, 3));
        dulce = new JCheckBox("Dulce");
        salado = new JCheckBox("Salado");
        saludable = new JCheckBox("Saludable");
        preferencias.add(dulce);
        preferencias.add(salado);
        preferencias.add(saludable);

        panel2.add(preferencias);
        
        panel2.add(new JLabel("TERMINOS Y CONDICIONES", SwingConstants.CENTER));
        aceptar = new JRadioButton("ACEPTAR");
        rechazar = new JRadioButton("RECHAZAR");
        termino.add(aceptar);
        termino.add(rechazar);
        JPanel condiciones = new JPanel(new GridLayout(1, 2));
        condiciones.add(aceptar);
        condiciones.add(rechazar);
        panel2.add(condiciones);
        
        String[] lugares = {"Elegir una ubicación", "La Fuente", "Camino Real", "Centro", "Miramar"};
        JComboBox<String> lugar = new JComboBox<>(lugares);
        panel2.add(lugar);
        
        login2 = new JButton("Iniciar Sesión"); //boton
        login2.addActionListener(new ActionListener() {
        	
        	public void actionPerformed(ActionEvent e) {
                
                		
        		String textoTF = usuario2.getText();
        		if(textoTF.equals("")) {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
        	               
                String textoTA = bio.getText();
                if(textoTA.equals("")) {
        			bio.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			bio.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
                
                if (aceptar.isSelected() && rechazar.isSelected()==false) {
                	aceptar.setBorder(BorderFactory.createLineBorder(Color.GREEN,3));
                } else {
                	aceptar.setBorder(BorderFactory.createLineBorder(Color.RED,3));
                }
                }
        		
        	
        });
        login2.setBackground(new Color(204, 255, 255));
        login2.setForeground(Color.BLACK);
        login2.setFont(new Font("Arial", Font.BOLD, 16));
        panel2.add(login2);
        
        panel2.add(new JLabel(" ", SwingConstants.CENTER));

        getContentPane().add(panel2);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
    }
    
    public void manager(String target) {
		this.getContentPane().removeAll();
		if(target.equals("Registro")) {
			getContentPane().add(this.registro());
		}
		if(target.equals("Login")) {
			getContentPane().add(this.login());
		}
		if(target.equals("Recuperar")) {
			getContentPane().add(this.recuperar());
		}
		if(target.equals("Alta")) {
			getContentPane().add(this.alta());
		}
		if(target.equals("Baja")) {
			getContentPane().add(this.baja());
		}
		if(target.equals("Consultar")) {
			getContentPane().add(this.consultar());
		}
		if(target.equals("Crear")) {
			getContentPane().add(this.crear());
		}
		if(target.equals("Acceder")) {
			getContentPane().add(this.acceder());
		}
		if(target.equals("Contrasena")) {
			getContentPane().add(this.contrasena());
		}
		
		this.repaint();
		this.revalidate();
		
	}
    
    public JPanel login() {
    	setTitle("Iniciar Sesion");
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel2 = new JPanel(new GridLayout(10, 1));
        panel2.setLocation(400, 0);
        
        
        JLabel etiqueta1 = new JLabel("INICIAR SESION", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);
        panel2.add(etiqueta1);
        
        panel2.add(new JLabel("Nombre de usuario:", SwingConstants.CENTER));
        usuario2 = new JTextField();
       
        panel2.add(usuario2);
        
        panel2.add(new JLabel("CONTRASEÑA:", SwingConstants.CENTER));
        
        passwordField = new JPasswordField();
        passwordField.setHorizontalAlignment(SwingConstants.LEFT);
        panel2.add(passwordField);
        
        chckbxNewCheckBox = new JCheckBox("MOSTRAR CONTRASEÑA");
        chckbxNewCheckBox.setForeground(new Color(153, 153, 153));
        chckbxNewCheckBox.setHorizontalAlignment(SwingConstants.CENTER);
        panel2.add(chckbxNewCheckBox);
        
        chckbxNewCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chckbxNewCheckBox.isSelected()) {
                    passwordField.setEchoChar((char) 0);
                } else {
                    passwordField.setEchoChar('*');
                }
            }
        });

        panel2.add(new JLabel("TERMINOS Y CONDICIONES", SwingConstants.CENTER));
        aceptar = new JRadioButton("ACEPTAR");
        aceptar.setHorizontalAlignment(SwingConstants.CENTER);
        rechazar = new JRadioButton("RECHAZAR");
        rechazar.setHorizontalAlignment(SwingConstants.CENTER);
        termino.add(aceptar);
        termino.add(rechazar);
        JPanel condiciones = new JPanel(new GridLayout(1, 2));
        condiciones.add(aceptar);
        condiciones.add(rechazar);
        panel2.add(condiciones);
        
        String[] lugares = {"Elegir una ubicación", "La Fuente", "Camino Real", "Centro", "Miramar"};
        
        login2 = new JButton("Iniciar Sesión"); //boton
        login2.addActionListener(new ActionListener() {
        	
        	public void actionPerformed(ActionEvent e) {
                
                		
        		String textoTF = usuario2.getText();
        		if(textoTF.equals("")) {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
        	               
                char[] password = passwordField.getPassword();
                if(password.length <= 0) {
                	passwordField.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			passwordField.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
                
                }
        		
        	
        });
        login2.setBackground(new Color(204, 255, 255));
        login2.setForeground(Color.BLACK);
        login2.setFont(new Font("Arial", Font.BOLD, 16));
        panel2.add(login2);
        
        panel2.add(new JLabel(" ", SwingConstants.CENTER));

        getContentPane().add(panel2);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
		return panel2;

    }
    
    public JPanel registro() {

        setTitle("Registro");
        setSize(400, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel2 = new JPanel(new GridLayout(12, 1));
        panel2.setLocation(400, 0);
        
        
        JLabel etiqueta1 = new JLabel("REGISTRO", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);
        panel2.add(etiqueta1);
        
        panel2.add(new JLabel("Nombre de usuario:", SwingConstants.CENTER));
        usuario2 = new JTextField();
       
        panel2.add(usuario2);
        
        panel2.add(new JLabel("BIO:", SwingConstants.CENTER));
        bio = new JTextArea();
		
        panel2.add(bio);
        
        panel2.add(new JLabel("PREFERENCIAS", SwingConstants.CENTER));
                
        JPanel preferencias = new JPanel(new GridLayout(1, 3));
        dulce = new JCheckBox("Dulce");
        salado = new JCheckBox("Salado");
        saludable = new JCheckBox("Saludable");
        preferencias.add(dulce);
        preferencias.add(salado);
        preferencias.add(saludable);

        panel2.add(preferencias);
        
        panel2.add(new JLabel("TERMINOS Y CONDICIONES", SwingConstants.CENTER));
        aceptar = new JRadioButton("ACEPTAR");
        rechazar = new JRadioButton("RECHAZAR");
        termino.add(aceptar);
        termino.add(rechazar);
        JPanel condiciones = new JPanel(new GridLayout(1, 2));
        condiciones.add(aceptar);
        condiciones.add(rechazar);
        panel2.add(condiciones);
        
        String[] lugares = {"Elegir una ubicación", "La Fuente", "Camino Real", "Centro", "Miramar"};
        JComboBox<String> lugar = new JComboBox<>(lugares);
        panel2.add(lugar);
        
        login2 = new JButton("Iniciar Sesión"); //boton
        login2.addActionListener(new ActionListener() {
        	
        	public void actionPerformed(ActionEvent e) {
                
                		
        		String textoTF = usuario2.getText();
        		if(textoTF.equals("")) {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
        	               
                String textoTA = bio.getText();
                if(textoTA.equals("")) {
        			bio.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			bio.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
                
                if (aceptar.isSelected() && rechazar.isSelected()==false) {
                	aceptar.setBorder(BorderFactory.createLineBorder(Color.GREEN,3));
                } else {
                	aceptar.setBorder(BorderFactory.createLineBorder(Color.RED,3));
                }
                }
        		
        	
        });
        login2.setBackground(new Color(204, 255, 255));
        login2.setForeground(Color.BLACK);
        login2.setFont(new Font("Arial", Font.BOLD, 16));
        panel2.add(login2);
        
        panel2.add(new JLabel(" ", SwingConstants.CENTER));

        getContentPane().add(panel2);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
        
        return panel2;
    }
    
    public JPanel recuperar() {
    	setTitle("Recuperar");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel2 = new JPanel(new GridLayout(8, 1));
        panel2.setLocation(400, 0);
        
        
        JLabel etiqueta1 = new JLabel("RECUPERAR CUENTA", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);
        panel2.add(etiqueta1);
        
        panel2.add(new JLabel("CORREO:", SwingConstants.CENTER));
        usuario2 = new JTextField();
       
        panel2.add(usuario2);
        
        panel2.add(new JLabel("NUEVA CONTRASEÑA:", SwingConstants.CENTER));
        
        passwordField = new JPasswordField();
        passwordField.setHorizontalAlignment(SwingConstants.LEFT);
        panel2.add(passwordField);
        
        chckbxNewCheckBox = new JCheckBox("MOSTRAR CONTRASEÑA");
        chckbxNewCheckBox.setForeground(new Color(153, 153, 153));
        chckbxNewCheckBox.setHorizontalAlignment(SwingConstants.CENTER);
        panel2.add(chckbxNewCheckBox);
        
        chckbxNewCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chckbxNewCheckBox.isSelected()) {
                    passwordField.setEchoChar((char) 0);
                } else {
                    passwordField.setEchoChar('*');
                }
            }
        });
        
        String[] lugares = {"Elegir una ubicación", "La Fuente", "Camino Real", "Centro", "Miramar"};
        
        login2 = new JButton("Recuperar cuenta"); //boton
        login2.addActionListener(new ActionListener() {
        	
        	public void actionPerformed(ActionEvent e) {
                
                		
        		String textoTF = usuario2.getText();
        		if(textoTF.equals("")) {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
        	               
                char[] password = passwordField.getPassword();
                if(password.length <= 0) {
                	passwordField.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			passwordField.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
                
                }
        		
        	
        });
        login2.setBackground(new Color(204, 255, 255));
        login2.setForeground(Color.BLACK);
        login2.setFont(new Font("Arial", Font.BOLD, 16));
        panel2.add(login2);
        
        panel2.add(new JLabel(" ", SwingConstants.CENTER));

        getContentPane().add(panel2);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
        
        return panel2;
    }
    
    public JPanel alta() {
    	setTitle("Alta");
        setSize(400, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel2 = new JPanel(new GridLayout(10, 1));
        panel2.setLocation(400, 0);
        
        
        JLabel etiqueta1 = new JLabel("ALTA", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);
        panel2.add(etiqueta1);
        
        panel2.add(new JLabel("NUMERO DE CONTROL:", SwingConstants.CENTER));
        usuario2 = new JTextField();
       
        panel2.add(usuario2);
        
        panel2.add(new JLabel("NOMBRE:", SwingConstants.CENTER));
        
        
        login2 = new JButton("Dar Alta"); //boton
        login2.addActionListener(new ActionListener() {
        	
        	public void actionPerformed(ActionEvent e) {
                
                		
        		String textoTF = usuario2.getText();
        		if(textoTF.equals("")) {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
        		String textoTF2 = NOMBRE.getText();
        		if(textoTF2.equals("")) {
        			NOMBRE.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			NOMBRE.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
        		String textoTF3 = CORREO.getText();
        		if(textoTF3.equals("")) {
        			CORREO.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			CORREO.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
                }
        });
        
        NOMBRE = new JTextField();
        panel2.add(NOMBRE);
        NOMBRE.setColumns(10);
        
        lblCorreo = new JLabel("CORREO:", SwingConstants.CENTER);
        panel2.add(lblCorreo);
        
        CORREO = new JTextField();
        CORREO.setColumns(10);
        panel2.add(CORREO);
        
        panel = new JPanel();
        panel2.add(panel);
        panel.setLayout(new BorderLayout(0, 0));
        
        table_1 = new JTable();
        table_1.setSurrendersFocusOnKeystroke(true);
        table_1.setForeground(new Color(0, 0, 0));
        table_1.setModel(new DefaultTableModel(
        	new Object[][] {
        		{"No Control", "Nombre", "Correo"},
        		{"123", "Eduardo", "edu@alu.uabcs.mx"},
        		{"542", "Zulidany", "zul@alu.uabcs.mx"},
        		{"375", "Erick", "eri@alu.uabcs.mx"},
        	},
        	new String[] {
        		"New column", "New column", "New column"
        	}
        ) {
        	Class[] columnTypes = new Class[] {
        		String.class, Object.class, Object.class
        	};
        	public Class getColumnClass(int columnIndex) {
        		return columnTypes[columnIndex];
        	}
        	boolean[] columnEditables = new boolean[] {
        		false, true, true
        	};
        	public boolean isCellEditable(int row, int column) {
        		return columnEditables[column];
        	}
        });
        table_1.getColumnModel().getColumn(0).setResizable(false);
        table_1.getColumnModel().getColumn(0).setPreferredWidth(55);
        table_1.getColumnModel().getColumn(2).setPreferredWidth(111);
        panel.add(table_1, BorderLayout.CENTER);
        
        lblNewLabel = new JLabel("             ");
        panel.add(lblNewLabel, BorderLayout.WEST);
        
        lblNewLabel_1 = new JLabel("             ");
        panel.add(lblNewLabel_1, BorderLayout.EAST);
        
        
        login2.setBackground(new Color(204, 255, 255));
        login2.setForeground(Color.BLACK);
        login2.setFont(new Font("Arial", Font.BOLD, 16));
        panel2.add(login2);
        
        panel2.add(new JLabel(" ", SwingConstants.CENTER));

        getContentPane().add(panel2);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
        
		return panel2;
    }
    
    public JPanel baja() {
    	setTitle("Baja");
        setSize(400, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel2 = new JPanel(new GridLayout(10, 1));
        panel2.setLocation(400, 0);
        
        
        JLabel etiqueta1 = new JLabel("BAJA", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);
        panel2.add(etiqueta1);
        
        panel2.add(new JLabel("NUMERO DE CONTROL:", SwingConstants.CENTER));
        usuario2 = new JTextField();
       
        panel2.add(usuario2);
        
        panel2.add(new JLabel("CORREO:", SwingConstants.CENTER));
        
        
        login2 = new JButton("Dar Baja"); //boton
        login2.addActionListener(new ActionListener() {
        	
        	public void actionPerformed(ActionEvent e) {
                
                		
        		String textoTF = usuario2.getText();
        		if(textoTF.equals("")) {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
        		String textoTF2 = NOMBRE.getText();
        		if(textoTF2.equals("")) {
        			NOMBRE.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			NOMBRE.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
        		String textoTA = textArea.getText();
                if(textoTA.equals("")) {
                	textArea.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			textArea.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
                }
        });
        
        NOMBRE = new JTextField();
        panel2.add(NOMBRE);
        NOMBRE.setColumns(10);
        
        lblCorreo = new JLabel("MOTIVO DE LA BAJA:", SwingConstants.CENTER);
        panel2.add(lblCorreo);
        
        textArea = new JTextArea();
        panel2.add(textArea);
        
        panel = new JPanel();
        panel2.add(panel);
        panel.setLayout(new BorderLayout(0, 0));
        
        table_1 = new JTable();
        table_1.setSurrendersFocusOnKeystroke(true);
        table_1.setForeground(new Color(0, 0, 0));
        table_1.setModel(new DefaultTableModel(
        	new Object[][] {
        		{"No Control", "Nombre", "Correo"},
        		{"123", "Eduardo", "edu@alu.uabcs.mx"},
        		{"542", "Zulidany", "zul@alu.uabcs.mx"},
        		{"375", "Erick", "eri@alu.uabcs.mx"},
        	},
        	new String[] {
        		"New column", "New column", "New column"
        	}
        ) {
        	Class[] columnTypes = new Class[] {
        		String.class, Object.class, Object.class
        	};
        	public Class getColumnClass(int columnIndex) {
        		return columnTypes[columnIndex];
        	}
        	boolean[] columnEditables = new boolean[] {
        		false, true, true
        	};
        	public boolean isCellEditable(int row, int column) {
        		return columnEditables[column];
        	}
        });
        table_1.getColumnModel().getColumn(0).setResizable(false);
        table_1.getColumnModel().getColumn(0).setPreferredWidth(55);
        table_1.getColumnModel().getColumn(2).setPreferredWidth(111);
        panel.add(table_1, BorderLayout.CENTER);
        
        lblNewLabel = new JLabel("             ");
        panel.add(lblNewLabel, BorderLayout.WEST);
        
        lblNewLabel_1 = new JLabel("             ");
        panel.add(lblNewLabel_1, BorderLayout.EAST);
        
        
        login2.setBackground(new Color(204, 255, 255));
        login2.setForeground(Color.BLACK);
        login2.setFont(new Font("Arial", Font.BOLD, 16));
        panel2.add(login2);
        
        panel2.add(new JLabel(" ", SwingConstants.CENTER));

        getContentPane().add(panel2);		
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
        
        return panel2;
    }
    
    public JPanel consultar() {
    	setTitle("Consulta");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel2 = new JPanel(new GridLayout(5, 1));
        panel2.setLocation(400, 0);
        
        
        JLabel etiqueta1 = new JLabel("CONSULTAR USUARIOS", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);
        panel2.add(etiqueta1);
        
        panel2.add(new JLabel("NUMERO DE CONTROL:", SwingConstants.CENTER));
        usuario2 = new JTextField();
       
        panel2.add(usuario2);
        
        
        login2 = new JButton("BUSCAR"); //boton
        login2.addActionListener(new ActionListener() {
        	
        	public void actionPerformed(ActionEvent e) {
                
                		
        		String textoTF = usuario2.getText();
        		if(textoTF.equals("")) {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        		}else {
        			usuario2.setBorder(BorderFactory.createLineBorder(Color.green,3));
        		}
                }
        });
        
        
        login2.setBackground(new Color(204, 255, 255));
        login2.setForeground(Color.BLACK);
        login2.setFont(new Font("Arial", Font.BOLD, 16));
        panel2.add(login2);
        
        panel2.add(new JLabel(" ", SwingConstants.CENTER));

        getContentPane().add(panel2);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
        
		return panel2;
    }
    
    public JPanel crear() {
    	setTitle("Crear cuenta");
        setSize(450, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel2 = new JPanel(new GridLayout(6, 1));
        panel2.setLocation(400, 0);
        
        
        JLabel etiqueta1 = new JLabel("COMO CREAR UN USUARIO", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);
        panel2.add(etiqueta1);
        
        panel2.add(new JLabel("1.LO PRIMERO ES ELEGIR EL NOMBRE DE USUARIO", SwingConstants.CENTER));
        
        panel2.add(new JLabel("2.JUNTO A SU NOMBRE, DEBERA AÑADIR UNA BREVE DESCRIPCION", SwingConstants.CENTER));
        
        panel2.add(new JLabel("3.SE DEBERA DE SELECCIONA SUS GUSTOS EN SABORES", SwingConstants.CENTER));
        
        panel2.add(new JLabel("4.Y PARA MEJOR RECOMENDACIONES SU COLONIA DE RESIDENCIA", SwingConstants.CENTER));

        
        panel2.add(new JLabel(" ", SwingConstants.CENTER));

        getContentPane().add(panel2);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
        
		return panel2;
    }
    
    public JPanel acceder() {
    	setTitle("Como acceder");
        setSize(450, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel2 = new JPanel(new GridLayout(6, 1));
        panel2.setLocation(400, 0);
        
        
        JLabel etiqueta1 = new JLabel("COMO ACCEDER AL SISTEMA", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);
        panel2.add(etiqueta1);
        
        panel2.add(new JLabel("1.PRIMERO INGRESAR SU NUMERO DE CONTROL", SwingConstants.CENTER));
        
        panel2.add(new JLabel("2.SU NOMBRE DEBE SER IGUAL AL DE SU REGISTRO", SwingConstants.CENTER));
        
        panel2.add(new JLabel("3.INGRESE SU CORREO ELECTRONICO PERSONAL", SwingConstants.CENTER));
        
        panel2.add(new JLabel("UNA VEZ SE VERIFIQUEN SUS DATOS, YA ESTARA DADO DE ALTA", SwingConstants.CENTER));

        
        panel2.add(new JLabel(" ", SwingConstants.CENTER));

        getContentPane().add(panel2);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
		return panel2;
    }
    
    public JPanel contrasena() {
    	setTitle("Reuperar contraseña");
        setSize(450, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel2 = new JPanel(new GridLayout(6, 1));
        panel2.setLocation(400, 0);
        
        
        JLabel etiqueta1 = new JLabel("OLVIDE MI CONTRASEÑA", SwingConstants.CENTER);
        etiqueta1.setFont(new Font("Arial", Font.BOLD, 24));
        etiqueta1.setForeground(Color.BLACK);
        panel2.add(etiqueta1);
        
        panel2.add(new JLabel("1.EN LA PESTAÑA 'CUENTA', INGRESE A 'RECUPERAR CUENTA'", SwingConstants.CENTER));
        
        panel2.add(new JLabel("2.INGRESE EL CORREO CUYA CONTRASEÑA PERDIO", SwingConstants.CENTER));
        
        panel2.add(new JLabel("3.AÑADA SU NUEVA CONTRASEÑA", SwingConstants.CENTER));
        
        panel2.add(new JLabel("SE ENVIARA UN CORREO DE CONFIRMACION A SU EMAIL Y LISTO", SwingConstants.CENTER));

        
        panel2.add(new JLabel(" ", SwingConstants.CENTER));

        getContentPane().add(panel2);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
        
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        mnNewMenu = new JMenu("Cuenta");
        menuBar.add(mnNewMenu);
        
        mntmNewMenuItem_1 = new JMenuItem("Login");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Login");
        		
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_1);
        
        mntmNewMenuItem = new JMenuItem("Registro");
        mntmNewMenuItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Registro");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem);
        
        mntmNewMenuItem_2 = new JMenuItem("Recuperacion de cuenta");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Recuperar");
        	}
        });
        mnNewMenu.add(mntmNewMenuItem_2);
        
        mnNewMenu_1 = new JMenu("Usuarios");
        menuBar.add(mnNewMenu_1);
        
        mntmNewMenuItem_3 = new JMenuItem("Alta");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Alta");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_3);
        
        mntmNewMenuItem_4 = new JMenuItem("Baja");
        mntmNewMenuItem_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Baja");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_4);
        
        mntmNewMenuItem_5 = new JMenuItem("Consultar");
        mntmNewMenuItem_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Consultar");
        	}
        });
        mnNewMenu_1.add(mntmNewMenuItem_5);
        
        mnNewMenu_2 = new JMenu("Ayuda");
        menuBar.add(mnNewMenu_2);
        
        mntmNewMenuItem_6 = new JMenuItem("Como crear usuario?");
        mntmNewMenuItem_6.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Crear");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_6);
        
        mntmNewMenuItem_7 = new JMenuItem("Como acceder al sistema?");
        mntmNewMenuItem_7.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Acceder");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_7);
        
        mntmNewMenuItem_8 = new JMenuItem("Olvide mi contraseña");
        mntmNewMenuItem_8.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		manager("Contrasena");
        	}
        });
        mnNewMenu_2.add(mntmNewMenuItem_8);
		return panel2;
    }

}
