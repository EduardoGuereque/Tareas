import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.SystemColor;
import javax.swing.JPanel;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JSlider;
import javax.swing.ImageIcon;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.UIManager;

public class Paint {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Paint window = new Paint();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Paint() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.activeCaption);
		frame.setBounds(250, 50, 850, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 816, 102);
		frame.getContentPane().add(panel);
		panel.setLayout(new GridLayout(0, 3, 0, 0));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(new LineBorder(null), "HERRAMIENTAS  ", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JButton btnNewButton = new JButton("PINCEL");
		btnNewButton.setBorder(UIManager.getBorder("ToggleButton.border"));
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBounds(40, 26, 89, 23);
		panel_2.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("GOMA");
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setBounds(169, 26, 89, 23);
		panel_2.add(btnNewButton_1);
		
		JSlider slider = new JSlider();
		slider.setBounds(40, 60, 218, 26);
		panel_2.add(slider);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new TitledBorder(new LineBorder(null), "FORMAS", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JButton btnNewButton_2 = new JButton(new ImageIcon("src/cuadrado-pequeno (1).png"));
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setBounds(20, 22, 89, 35);
		panel_3.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton(new ImageIcon("src/circulo-pequeno.png"));
		btnNewButton_3.setBackground(Color.WHITE);
		btnNewButton_3.setBounds(20, 57, 89, 34);
		panel_3.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton(new ImageIcon("src/triangulo (1).png"));
		btnNewButton_4.setBackground(Color.WHITE);
		btnNewButton_4.setBounds(169, 22, 89, 35);
		panel_3.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton(new ImageIcon("src/regla-horizontal.png"));
		btnNewButton_5.setBackground(Color.WHITE);
		btnNewButton_5.setBounds(169, 57, 89, 34);
		panel_3.add(btnNewButton_5);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new TitledBorder(new LineBorder(null), "COLORES", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.add(panel_4);
		panel_4.setLayout(null);
		
		JButton btnNewButton_6 = new JButton("");
		btnNewButton_6.setBackground(Color.WHITE);
		btnNewButton_6.setBounds(10, 26, 25, 25);
		panel_4.add(btnNewButton_6);
		
		JButton btnNewButton_6_1 = new JButton("");
		btnNewButton_6_1.setBackground(Color.GRAY);
		btnNewButton_6_1.setBounds(10, 66, 25, 25);
		panel_4.add(btnNewButton_6_1);
		
		JButton btnNewButton_6_2 = new JButton("");
		btnNewButton_6_2.setBackground(Color.BLACK);
		btnNewButton_6_2.setBounds(45, 26, 25, 25);
		panel_4.add(btnNewButton_6_2);
		
		JButton btnNewButton_6_3 = new JButton("");
		btnNewButton_6_3.setBackground(Color.PINK);
		btnNewButton_6_3.setBounds(45, 66, 25, 25);
		panel_4.add(btnNewButton_6_3);
		
		JButton btnNewButton_6_4 = new JButton("");
		btnNewButton_6_4.setBackground(Color.LIGHT_GRAY);
		btnNewButton_6_4.setBounds(80, 26, 25, 25);
		panel_4.add(btnNewButton_6_4);
		
		JButton btnNewButton_6_5 = new JButton("");
		btnNewButton_6_5.setBackground(Color.CYAN);
		btnNewButton_6_5.setBounds(80, 66, 25, 25);
		panel_4.add(btnNewButton_6_5);
		
		JButton btnNewButton_6_6 = new JButton("");
		btnNewButton_6_6.setBackground(Color.BLUE);
		btnNewButton_6_6.setBounds(115, 26, 25, 25);
		panel_4.add(btnNewButton_6_6);
		
		JButton btnNewButton_6_1_1 = new JButton("");
		btnNewButton_6_1_1.setBackground(Color.ORANGE);
		btnNewButton_6_1_1.setBounds(115, 66, 25, 25);
		panel_4.add(btnNewButton_6_1_1);
		
		JButton btnNewButton_6_2_1 = new JButton("");
		btnNewButton_6_2_1.setBackground(Color.RED);
		btnNewButton_6_2_1.setBounds(150, 26, 25, 25);
		panel_4.add(btnNewButton_6_2_1);
		
		JButton btnNewButton_6_3_1 = new JButton("");
		btnNewButton_6_3_1.setBackground(SystemColor.info);
		btnNewButton_6_3_1.setBounds(150, 66, 25, 25);
		panel_4.add(btnNewButton_6_3_1);
		
		JButton btnNewButton_6_4_1 = new JButton("");
		btnNewButton_6_4_1.setBackground(Color.GREEN);
		btnNewButton_6_4_1.setBounds(185, 26, 25, 25);
		panel_4.add(btnNewButton_6_4_1);
		
		JButton btnNewButton_6_5_1 = new JButton("");
		btnNewButton_6_5_1.setBackground(SystemColor.activeCaption);
		btnNewButton_6_5_1.setBounds(185, 66, 25, 25);
		panel_4.add(btnNewButton_6_5_1);
		
		JButton btnNewButton_6_4_1_1 = new JButton("");
		btnNewButton_6_4_1_1.setBackground(Color.YELLOW);
		btnNewButton_6_4_1_1.setBounds(220, 26, 25, 25);
		panel_4.add(btnNewButton_6_4_1_1);
		
		JButton btnNewButton_6_5_1_1 = new JButton("");
		btnNewButton_6_5_1_1.setBackground(new Color(118, 80, 10));
		btnNewButton_6_5_1_1.setBounds(220, 66, 25, 25);
		panel_4.add(btnNewButton_6_5_1_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 124, 816, 400);
		frame.getContentPane().add(panel_1);
		
		JButton btnNewButton_7 = new JButton("BORRAR");
		btnNewButton_7.setBackground(Color.WHITE);
		btnNewButton_7.setBounds(350, 529, 100, 23);
		frame.getContentPane().add(btnNewButton_7);
	}
}
