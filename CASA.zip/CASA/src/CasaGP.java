import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JFrame;

public class CasaGP extends JFrame {

	public CasaGP() {
    	
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	
    	setTitle("Casita");
        setSize(700, 700);
        setLocationRelativeTo(null);
        setVisible(true);
        this.setBackground(Color.BLACK);
        
	}
	
	public void paint(Graphics g) {
    	
    	super.paint(g);
    	
    	Graphics g2 = (Graphics2D) g;
    	g2.setColor(new Color(166, 251, 250));//fondo
    	g2.fillRect(0, 0, 700, 700);
    	g2.setColor(new Color(255, 246, 143));//casa
    	g2.fillRect(150, 250, 400, 400);
    	g2.setColor(new Color(164, 97, 0));//lineas casa
    	g2.fillRect(150, 300, 400, 5);
    	g2.fillRect(150, 350, 400, 5);
    	g2.fillRect(150, 400, 400, 5);
    	g2.fillRect(150, 450, 400, 5);
    	g2.fillRect(150, 500, 400, 5);
    	g2.fillRect(150, 550, 400, 5);
    	g2.fillRect(150, 600, 400, 5);
    	g2.setColor(new Color(175, 215, 214));//marcoventana
    	g2.fillRect(390, 340, 120, 170);
    	g2.setColor(new Color(206, 252, 252));//ventana
    	g2.fillRect(400, 350, 100, 150);
    	g2.setColor(new Color(175, 215, 214));//lineasVentana
    	g2.fillRect(400, 425, 100, 5);
    	g2.fillRect(450, 350, 5, 150);
    	g2.setColor(new Color(234, 185, 115));//cerca
    	g2.fillRect(0, 530, 700, 20);
    	g2.fillRect(0, 570, 700, 20);
    	g2.fillRect(0, 610, 700, 20);
    	g2.setColor(new Color(234, 185, 115));//cerca2
    	g2.fillRect(10, 450, 30, 250);
    	g2.fillRect(80, 450, 30, 250);
    	g2.fillRect(150, 450, 30, 250);
    	g2.fillRect(290, 450, 30, 250);
    	g2.fillRect(360, 450, 30, 250);
    	g2.fillRect(430, 450, 30, 250);
    	g2.fillRect(500, 450, 30, 250);
    	g2.fillRect(570, 450, 30, 250);
    	g2.fillRect(640, 450, 30, 250);
    	g2.setColor(new Color(104, 245, 28));//pasto
    	g2.fillRect(0, 650, 700, 50);
    	g2.setColor(new Color(164, 97, 0));//marco puerta
    	g2.fillRect(215, 495, 60, 150);
    	g2.setColor(Color.WHITE);//puerta
    	g2.fillRect(220, 500, 50, 140);
    	g2.setColor(Color.RED);
    	int[] x = {100,450,600};//techo
    	int[] y = {250,100,250};
    	g2.fillPolygon(x, y, 3);
    	g2.setColor(Color.RED);//chimenea
    	g2.fillRect(475, 100, 70, 100);
    	//g2.fillRect(570, 450, 30, 250);
	
    
    }
	
}
