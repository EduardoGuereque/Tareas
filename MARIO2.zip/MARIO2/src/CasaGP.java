import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class CasaGP extends JFrame {

	public CasaGP() {
    	
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	
    	setTitle("Super Mario World");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setVisible(true);
        this.setBackground(Color.BLACK);
        
	}
	
	public void paint(Graphics g) {
    	
    	super.paint(g);
    	
    	Graphics g2 = (Graphics2D) g;
    	g2.setColor(new Color(3, 90, 185));//fondo
    	g2.fillRect(0, 0, 1000, 700);
    	g2.setColor(new Color(234, 240, 254));//NubesDetras
    	g2.fillArc(275, 450, 250, 50, 0, 360);
    	g2.fillArc(105, 500, 250, 50, 0, 360);
    	g2.fillArc(275, 550, 250, 50, 0, 360);
    	g2.fillArc(655, 200, 250, 50, 0, 360);
    	g2.setColor(new Color(190, 223, 227));//AzulClaro
    	g2.fillRect(480, 270, 150, 400);
    	g2.setColor(new Color(190, 223, 227));//AzulClaroCirculo
    	g2.fillArc(480, 200, 150, 150, 0, 180);
    	g2.setColor(new Color(190, 223, 227));//AzulClaro2
    	g2.fillRect(630, 220, 150, 600);
    	g2.setColor(new Color(190, 223, 227));//AzulClaroCirculo2
    	g2.fillArc(630, 150, 150, 150, 0, 180);
    	g2.setColor(new Color(190, 223, 227));//AzulClaro3
    	g2.fillRect(20, 270, 150, 400);
    	g2.setColor(new Color(190, 223, 227));//AzulClaroCirculo3
    	g2.fillArc(20, 200, 150, 150, 0, 180);
    	g2.setColor(new Color(234, 240, 254));//Nubes
    	g2.fillArc(-105, 250, 250, 50, 0, 360);
    	g2.fillArc(170, 350, 250, 50, 0, 360);
    	g2.fillArc(775, 150, 250, 50, 0, 360);
    	g2.fillArc(635, 350, 250, 50, 0, 360);
    	g2.fillArc(120, 220, 20, 30, 0, 360);
    	g2.fillArc(120, 300, 20, 30, 0, 360);
    	g2.fillArc(95, 400, 20, 30, 0, 360);
    	g2.fillArc(500, 275, 20, 30, 0, 360);
    	g2.fillArc(500, 325, 20, 30, 0, 360);
    	g2.fillArc(540, 290, 20, 30, 0, 360);
    	g2.fillArc(650, 210, 20, 30, 0, 360);
    	g2.fillArc(650, 290, 20, 30, 0, 360);
    	g2.setColor(new Color(106, 169, 210));//AzulOscuro
    	g2.fillRect(500, 420, 150, 250);
    	g2.setColor(new Color(106, 169, 210));//AzulOscuroCirculo
    	g2.fillArc(500, 350, 150, 150, 0, 180);	
    	g2.setColor(new Color(106, 169, 210));//AzulOscuro2
    	g2.fillRect(700, 320, 200, 250);
    	g2.setColor(new Color(106, 169, 210));//AzulOscuroCirculo2
    	g2.fillArc(700, 250, 200, 150, 0, 180);	
    	g2.setColor(new Color(106, 169, 210));//AzulOscuro3
    	g2.fillRect(-50, 420, 150, 250);
    	g2.setColor(new Color(106, 169, 210));//AzulOscuroCirculo3
    	g2.fillArc(-50, 350, 150, 150, 0, 180);	
    	g2.setColor(new Color(192, 222, 222));//NubesOscuras
    	g2.fillArc(720, 350, 20, 30, 0, 360);
    	g2.fillArc(810, 500, 20, 30, 0, 360);
    	
    	g2.setColor(Color.BLACK);//cajasAireContorno
    	g2.fillRect(845, 485, 85, 85);//1
    	g2.fillRect(845, 405, 85, 85);//2
    	g2.fillRect(845, 325, 85, 85);//3
    	g2.fillRect(845, 245, 85, 85);//4
    	g2.fillRect(925, 245, 85, 85);//amarilla
    	g2.setColor(new Color(191, 188, 192));//cajasAire
    	g2.fillRect(850, 490, 75, 75);//1
    	g2.fillRect(850, 410, 75, 75);//2
    	g2.fillRect(850, 330, 75, 75);//3
    	g2.fillRect(850, 250, 75, 75);//4
    	g2.setColor(new Color(253, 211, 33));//cajaAmarilla
    	g2.fillRect(930, 250, 75, 75);//amarilla
    	g2.setColor(Color.BLACK);//tuberiaContorno
    	g2.fillRect(950, 445, 130, 130);
    	g2.setColor(new Color(126, 121, 201));//tuberia
    	g2.fillRect(955, 450, 120, 120);
    	g2.setColor(Color.BLACK);//tuberiaContorno
    	g2.fillRect(930, 405, 168, 60);
    	g2.setColor(new Color(126, 121, 201));//tuberiaArriba
    	g2.fillRect(935, 410, 158, 50);	
    	
    	g2.setColor(Color.BLACK);//tuberiaContorno
    	g2.fillRect(530, 445, 130, 130);
    	g2.setColor(new Color(126, 121, 201));//tuberia
    	g2.fillRect(535, 450, 120, 120);
    	g2.setColor(Color.BLACK);//tuberiaContorno
    	g2.fillRect(510, 405, 168, 60);
    	g2.setColor(new Color(126, 121, 201));//tuberiaArriba
    	g2.fillRect(515, 410, 158, 50);	
    	g2.setColor(Color.BLACK);//pisoContorno
    	g2.fillRect(0, 565, 1000, 30);
    	g2.setColor(new Color(24, 193, 24));//piso
    	g2.fillRect(0, 570, 1000, 30);
    	g2.setColor(Color.BLACK);//pisoFrenteContorno
    	g2.fillRect(0, 595, 1000, 100);
    	g2.setColor(new Color(201, 146, 89));//pisoFrente
    	g2.fillRect(0, 600, 1000, 100);
    
    }
	
}
