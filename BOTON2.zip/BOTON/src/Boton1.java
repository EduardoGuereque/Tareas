import java.awt.Color;
import java.awt.EventQueue;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.awt.SystemColor;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;

public class Boton1 {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Boton1 window = new Boton1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Boton1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.activeCaption);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.activeCaption);
		panel.setBounds(10, 11, 366, 541);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		Random x = new Random();
		Random y = new Random();
		Random w = new Random();
		Random h = new Random();
		
		JButton btnNewButton = new JButton("CLICKEAME");
		btnNewButton.setBackground(SystemColor.menu);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int maxWidth = 100;
		        int maxHeight = 100;
		        int maxX = panel.getWidth() - maxWidth;
		        int maxY = panel.getHeight() - maxHeight;

		        int width = 20 + w.nextInt(maxWidth);
		        int height = 20 + h.nextInt(maxHeight);
		        int posx = x.nextInt(maxX);
		        int posy = y.nextInt(maxY);

		        JButton newButton = new JButton("" + posx);
		        newButton.setFont(new Font("Verdana", Font.BOLD, 11));
		        newButton.setBackground(new Color(0,height,width));
		        newButton.setBounds(posx, posy, width, height);
		        panel.add(newButton);
		        
		        newButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
							
						JOptionPane.showMessageDialog(null, newButton.getText());
						
					}
				});

		        panel.revalidate();
		        panel.repaint();
			}
		});
		btnNewButton.setBounds(44, 425, 279, 93);
		panel.add(btnNewButton);
		frame.setBounds(100, 100, 400, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
