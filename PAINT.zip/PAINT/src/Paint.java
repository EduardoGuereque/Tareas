import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JFrame;
import java.awt.SystemColor;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.Point;
import javax.swing.JButton;
import javax.swing.JSlider;
import javax.swing.ImageIcon;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;
import java.awt.BasicStroke;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class Paint implements MouseListener, MouseMotionListener {

    private JFrame frame;
    private ArrayList<Point> puntosActuales = new ArrayList<>();
    private List<Trazo> trazos = new ArrayList<>(); 
    private PaintPanel panel_1;
    private Color colorActual = Color.BLACK;
    private BasicStroke trazoActual = new BasicStroke(3);

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Paint window = new Paint();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Paint() {
        initialize();
    }
    
    class Trazo {
        List<Point> puntos;
        Color color;
        BasicStroke grosor;

        public Trazo(List<Point> puntos, Color color, BasicStroke grosor) {
            this.puntos = new ArrayList<>(puntos);
            this.color = color;
            this.grosor = grosor;
        }
        
        public void dibujar(Graphics2D g2) {
            if(puntos.size() > 1) {
                g2.setColor(color);
                g2.setStroke(grosor);
                for (int i = 1; i < puntos.size(); i++) {
                    Point p1 = puntos.get(i-1);
                    Point p2 = puntos.get(i);
                    g2.drawLine(p1.x, p1.y, p2.x, p2.y);
                }
            }
        }
    }

    private void initialize() {
        frame = new JFrame("Paint");
        frame.getContentPane().setBackground(SystemColor.activeCaption);
        frame.setBounds(250, 50, 850, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        
        JPanel panel = new JPanel();
        panel.setBounds(10, 11, 816, 102);
        frame.getContentPane().add(panel);
        panel.setLayout(new GridLayout(0, 3, 0, 0));
        
        JPanel panel_2 = new JPanel();
        panel_2.setBorder(new TitledBorder(new LineBorder(null), "HERRAMIENTAS  ", TitledBorder.LEADING, TitledBorder.TOP, null, null));
        panel.add(panel_2);
        panel_2.setLayout(null);
        
        JButton btnPincel = new JButton("PINCEL");
        btnPincel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                colorActual = Color.BLACK;
            }
        });
        btnPincel.setBorder(UIManager.getBorder("ToggleButton.border"));
        btnPincel.setBackground(Color.WHITE);
        btnPincel.setBounds(40, 26, 89, 23);
        panel_2.add(btnPincel);
        
        JButton btnGoma = new JButton("GOMA");
        btnGoma.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                colorActual = Color.WHITE;
            }
        });
        btnGoma.setBackground(Color.WHITE);
        btnGoma.setBounds(169, 26, 89, 23);
        panel_2.add(btnGoma);
        
        JSlider slider = new JSlider();
        slider.setBounds(40, 60, 218, 26);
        slider.setMinimum(1);
        slider.setMaximum(20);
        slider.setValue(3);
        slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                trazoActual = new BasicStroke(slider.getValue());
            }
        });
        panel_2.add(slider);
        
        JPanel panel_3 = new JPanel();
        panel_3.setBorder(new TitledBorder(new LineBorder(null), "FORMAS", TitledBorder.LEADING, TitledBorder.TOP, null, null));
        panel.add(panel_3);
        panel_3.setLayout(null);
        
        JButton btnCuadrado = new JButton(new ImageIcon("src/cuadrado-pequeno (1).png"));
        btnCuadrado.setBackground(Color.WHITE);
        btnCuadrado.setBounds(20, 22, 89, 35);
        panel_3.add(btnCuadrado);
        
        JButton btnCirculo = new JButton(new ImageIcon("src/circulo-pequeno.png"));
        btnCirculo.setBackground(Color.WHITE);
        btnCirculo.setBounds(20, 57, 89, 34);
        panel_3.add(btnCirculo);
        
        JButton btnTriangulo = new JButton(new ImageIcon("src/triangulo (1).png"));
        btnTriangulo.setBackground(Color.WHITE);
        btnTriangulo.setBounds(169, 22, 89, 35);
        panel_3.add(btnTriangulo);
        
        JButton btnLinea = new JButton(new ImageIcon("src/regla-horizontal.png"));
        btnLinea.setBackground(Color.WHITE);
        btnLinea.setBounds(169, 57, 89, 34);
        panel_3.add(btnLinea);
        
        JPanel panel_4 = new JPanel();
        panel_4.setBorder(new TitledBorder(new LineBorder(null), "COLORES", TitledBorder.LEADING, TitledBorder.TOP, null, null));
        panel.add(panel_4);
        panel_4.setLayout(null);
        
        JButton[] colores = new JButton[14];
        colores[0] = botonColores(Color.WHITE, 10, 26);
        colores[1] = botonColores(Color.GRAY, 10, 66);
        colores[2] = botonColores(Color.BLACK, 45, 26);
        colores[3] = botonColores(Color.PINK, 45, 66);
        colores[4] = botonColores(Color.LIGHT_GRAY, 80, 26);
        colores[5] = botonColores(Color.CYAN, 80, 66);
        colores[6] = botonColores(Color.BLUE, 115, 26);
        colores[7] = botonColores(Color.ORANGE, 115, 66);
        colores[8] = botonColores(Color.RED, 150, 26);
        colores[9] = botonColores(SystemColor.info, 150, 66);
        colores[10] = botonColores(Color.GREEN, 185, 26);
        colores[11] = botonColores(SystemColor.activeCaption, 185, 66);
        colores[12] = botonColores(Color.YELLOW, 220, 26);
        colores[13] = botonColores(new Color(118, 80, 10), 220, 66);
        
        for (JButton button : colores) {
            panel_4.add(button);
        }
        
        panel_1 = new PaintPanel();
        panel_1.setBounds(10, 124, 816, 400);
        panel_1.addMouseListener(this);
        panel_1.addMouseMotionListener(this);
        frame.getContentPane().add(panel_1);
        
        JButton btnBorrar = new JButton("BORRAR");
        btnBorrar.setBackground(Color.WHITE);
        btnBorrar.setBounds(350, 529, 100, 23);
        btnBorrar.addActionListener(e -> {
            trazos.clear();
            puntosActuales.clear();
            panel_1.repaint();
        });
        frame.getContentPane().add(btnBorrar);
    }
    
    private JButton botonColores(Color color, int x, int y) {
        JButton button = new JButton("");
        button.setBackground(color);
        button.setBounds(x, y, 25, 25);
        button.addActionListener(e -> {
            colorActual = color;
        });
        return button;
    }

    class PaintPanel extends JPanel {
        public PaintPanel() {
            this.setBackground(Color.white);
        }

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;

            for (Trazo trazo : trazos) {
                trazo.dibujar(g2);
            }

            if(puntosActuales.size() > 1) {
                g2.setColor(colorActual);
                g2.setStroke(trazoActual);
                for (int i = 1; i < puntosActuales.size(); i++) {
                    Point p1 = puntosActuales.get(i-1);
                    Point p2 = puntosActuales.get(i);
                    g2.drawLine(p1.x, p1.y, p2.x, p2.y);
                }
            }
        }
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        puntosActuales.add(e.getPoint());
        panel_1.repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {}

    @Override
    public void mouseClicked(MouseEvent e) {}

    @Override
    public void mousePressed(MouseEvent e) {
        puntosActuales.clear();
        puntosActuales.add(e.getPoint());
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (!puntosActuales.isEmpty()) {
            trazos.add(new Trazo(puntosActuales, colorActual, trazoActual));
            puntosActuales.clear();
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}
}