import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class CasaGP extends JFrame {

	public CasaGP() {
    	
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	
    	setTitle("Super Mario 3");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setVisible(true);
        this.setBackground(Color.BLACK);
        
	}
	
	public void paint(Graphics g) {
    	
    	super.paint(g);
    	
    	Graphics g2 = (Graphics2D) g;
    	g2.setColor(new Color(162, 240, 255));//fondo
    	g2.fillRect(0, 0, 1000, 700);
    	g2.setColor(Color.BLACK);//cajaAzulContorno
    	g2.fillRect(295, 315, 160, 255);
    	g2.setColor(new Color(113, 194, 255));//cajaAzul
    	g2.fillRect(300, 320, 150, 250);
    	g2.setColor(Color.BLACK);//cajaRosaContorno
    	g2.fillRect(195, 415, 160, 155);
    	g2.setColor(new Color(255, 192, 181));//cajaRosa
    	g2.fillRect(200, 420, 150, 150);
    	g2.setColor(Color.BLACK);//cajasAireContorno
    	g2.fillRect(45, 215, 85, 85);
    	g2.fillRect(205, 45, 85, 85);
    	g2.fillRect(285, 45, 85, 85);
    	g2.fillRect(745, 215, 85, 85);
    	g2.setColor(new Color(255, 137, 84));//cajasAire
    	g2.fillRect(50, 220, 75, 75);
    	g2.fillRect(210, 50, 75, 75);
    	g2.fillRect(290, 50, 75, 75);
    	g2.fillRect(750, 220, 75, 75);
    	g2.setColor(Color.BLACK);//cajaVerdeContorno
    	g2.fillRect(865, 415, 160, 160);
    	g2.setColor(new Color(0, 221, 91));//cajaVerde
    	g2.fillRect(870, 420, 150, 150);
    	g2.setColor(Color.BLACK);//tornillos
    	g2.drawArc(880, 430, 20, 20, 0, 360);
    	g2.drawArc(880, 535, 20, 20, 0, 360);
    	g2.drawArc(320, 430, 20, 20, 0, 360);
    	g2.drawArc(320, 535, 20, 20, 0, 360);
    	g2.drawArc(310, 330, 20, 20, 0, 360);
    	g2.drawArc(420, 330, 20, 20, 0, 360);
    	g2.drawArc(420, 535, 20, 20, 0, 360);
    	g2.drawArc(210, 430, 20, 20, 0, 360);
    	g2.drawArc(210, 535, 20, 20, 0, 360);
    	g2.setColor(Color.BLACK);//tornillos2
    	g2.fillRect(55, 225, 5, 5);
    	g2.fillRect(115, 225, 5, 5);
    	g2.fillRect(115, 285, 5, 5);
    	g2.fillRect(55, 285, 5, 5);
    	
    	g2.fillRect(215, 55, 5, 5);
    	g2.fillRect(215, 115, 5, 5);
    	g2.fillRect(275, 115, 5, 5);
    	g2.fillRect(275, 55, 5, 5);
    	
    	g2.fillRect(295, 55, 5, 5);
    	g2.fillRect(295, 115, 5, 5);
    	g2.fillRect(355, 115, 5, 5);
    	g2.fillRect(355, 55, 5, 5);
    	
    	g2.fillRect(755, 225, 5, 5);
    	g2.fillRect(815, 225, 5, 5);
    	g2.fillRect(815, 285, 5, 5);
    	g2.fillRect(755, 285, 5, 5);
    	
    	g2.setColor(Color.BLACK);//tuberiaContorno
    	g2.fillRect(530, 445, 130, 130);
    	g2.setColor(new Color(0, 124, 0));//tuberia
    	g2.fillRect(535, 450, 120, 120);
    	g2.setColor(Color.BLACK);//tuberiaContorno
    	g2.fillRect(510, 405, 168, 60);
    	g2.setColor(new Color(0, 124, 0));//tuberiaArriba
    	g2.fillRect(515, 410, 158, 50);
    	g2.setColor(Color.BLACK);//arbustoContorno
    	g2.fillArc(45, 515, 110, 110, 0, 180);
    	g2.setColor(new Color(33, 131, 4));//arbusto
    	g2.fillArc(50, 520, 100, 100, 0, 180);
    	
        
    	g2.setColor(Color.BLACK);//pisoContorno
    	g2.fillRect(0, 565, 1000, 30);
    	g2.setColor(new Color(177, 111, 59));//piso
    	g2.fillRect(0, 570, 1000, 30);
    	g2.setColor(Color.BLACK);//pisoFrenteContorno
    	g2.fillRect(0, 595, 1000, 100);
    	g2.setColor(new Color(252, 149, 89));//pisoFrente
    	g2.fillRect(0, 600, 1000, 100);
    	g2.setColor(new Color(99, 61, 32));//pisoFrenteLineas
    	g2.fillRect(0, 615, 1000, 5);
    	g2.fillRect(0, 635, 1000, 5);
    	g2.fillRect(0, 655, 1000, 5);
    	
    	g2.fillRect(0, 600, 5, 100);
    	g2.fillRect(30, 600, 5, 100);
    	g2.fillRect(60, 600, 5, 100);
    	g2.fillRect(90, 600, 5, 100);
    	g2.fillRect(120, 600, 5, 100);
    	g2.fillRect(150, 600, 5, 100);
    	g2.fillRect(180, 600, 5, 100);
    	g2.fillRect(210, 600, 5, 100);
    	g2.fillRect(240, 600, 5, 100);
    	g2.fillRect(270, 600, 5, 100);
    	g2.fillRect(300, 600, 5, 100);
    	g2.fillRect(330, 600, 5, 100);
    	g2.fillRect(360, 600, 5, 100);
    	g2.fillRect(390, 600, 5, 100);
    	g2.fillRect(420, 600, 5, 100);
    	g2.fillRect(450, 600, 5, 100);
    	g2.fillRect(480, 600, 5, 100);
    	g2.fillRect(510, 600, 5, 100);
    	g2.fillRect(540, 600, 5, 100);
    	g2.fillRect(570, 600, 5, 100);
    	g2.fillRect(600, 600, 5, 100);
    	g2.fillRect(630, 600, 5, 100);
    	g2.fillRect(660, 600, 5, 100);
    	g2.fillRect(690, 600, 5, 100);
    	g2.fillRect(720, 600, 5, 100);
    	g2.fillRect(750, 600, 5, 100);
    	g2.fillRect(780, 600, 5, 100);
    	g2.fillRect(810, 600, 5, 100);
    	g2.fillRect(840, 600, 5, 100);
    	g2.fillRect(870, 600, 5, 100);
    	g2.fillRect(900, 600, 5, 100);
    	g2.fillRect(930, 600, 5, 100);
    	g2.fillRect(960, 600, 5, 100);
    	g2.fillRect(990, 600, 5, 100);
    	
    	BufferedImage image;
    	try {
    		image = ImageIO.read(new File("recursos/mario.png"));
    		
    		g2.drawImage(image,400,525,50,75,null,null);
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
	
    
    }
	
}
