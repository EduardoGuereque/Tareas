import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.Rectangle;
import java.awt.SystemColor;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.Toolkit;

public class Rompe {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Rompe window = new Rompe();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Rompe() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("src/22212-monkey-icon.png"));
		frame.getContentPane().setBackground(SystemColor.activeCaption);
		frame.setBackground(SystemColor.activeCaption);
		frame.getContentPane().setBounds(new Rectangle(500, 500, 500, 50));
		frame.setBounds(450, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.activeCaption);
		frame.getContentPane().add(panel, BorderLayout.NORTH);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(SystemColor.activeCaption);
		frame.getContentPane().add(panel_1, BorderLayout.SOUTH);
		
		JButton btnNewButton_16 = new JButton("Reiniciar");
		panel_1.add(btnNewButton_16);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(SystemColor.activeCaption);
		frame.getContentPane().add(panel_2, BorderLayout.WEST);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(SystemColor.activeCaption);
		frame.getContentPane().add(panel_3, BorderLayout.EAST);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "99% imposible ", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_4.setBackground(SystemColor.activeCaption);
		frame.getContentPane().add(panel_4, BorderLayout.CENTER);
		panel_4.setLayout(new GridLayout(4, 4, 10, 10));
		
		JButton btnNewButton = new JButton("1");
		panel_4.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("2");
		panel_4.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("3");
		panel_4.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("4");
		panel_4.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("5");
		panel_4.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("6");
		panel_4.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("7");
		panel_4.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("8");
		panel_4.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("9");
		panel_4.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("10");
		panel_4.add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("11");
		panel_4.add(btnNewButton_10);
		
		JButton btnNewButton_11 = new JButton("12");
		panel_4.add(btnNewButton_11);
		
		JButton btnNewButton_12 = new JButton("13");
		panel_4.add(btnNewButton_12);
		
		JButton btnNewButton_13 = new JButton("14");
		panel_4.add(btnNewButton_13);
		
		JButton btnNewButton_14 = new JButton("15");
		panel_4.add(btnNewButton_14);
		
		JButton btnNewButton_15 = new JButton(" ");
		panel_4.add(btnNewButton_15);
	}

}
