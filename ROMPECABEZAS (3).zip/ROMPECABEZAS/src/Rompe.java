import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.Rectangle;
import java.awt.SystemColor;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Rompe {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Rompe window = new Rompe();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Rompe() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	String[] numeros = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15", ""};
	JPanel panel_4;
	JButton[] botones = new JButton[16];
	int espacioIndex = 15;
	int segundos = 0;
    boolean marcha = false;
    Timer cronometro;
    JLabel timer;
	
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("src/22212-monkey-icon.png"));
		frame.getContentPane().setBackground(SystemColor.activeCaption);
		frame.setBackground(SystemColor.activeCaption);
		frame.getContentPane().setBounds(new Rectangle(500, 500, 500, 50));
		frame.setBounds(450, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.activeCaption);
		frame.getContentPane().add(panel, BorderLayout.NORTH);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(SystemColor.activeCaption);
		frame.getContentPane().add(panel_1, BorderLayout.SOUTH);
		
		JButton btnNewButton_16 = new JButton("Reiniciar");
		btnNewButton_16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				reiniciarJuego();
		        
		        for (int i = 0; i < numeros.length; i++) {
		            if (numeros[i].equals("")) {
		                espacioIndex = i;
		                break;
		            }
		        }

		        actualizar();
		        
		        panel_4.revalidate();
		        panel_4.repaint(); 
			}
		});
		panel_1.add(btnNewButton_16);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(SystemColor.activeCaption);
		frame.getContentPane().add(panel_2, BorderLayout.WEST);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(SystemColor.activeCaption);
		frame.getContentPane().add(panel_3, BorderLayout.EAST);
		panel_3.setLayout(new GridLayout(6, 1, 5, 15));
		
		JLabel lblNewLabel_1 = new JLabel(" ");
		panel_3.add(lblNewLabel_1);
		
		timer = new JLabel("00:00");
        timer.setHorizontalAlignment(SwingConstants.CENTER);
        panel_3.add(timer);
		
		JLabel lblNewLabel_2 = new JLabel(" ");
		panel_3.add(lblNewLabel_2);
		
		JButton btnNewButton_17 = new JButton("Iniciar");
		btnNewButton_17.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iniciar();
            }
        });
		panel_3.add(btnNewButton_17);
		
		JButton btnNewButton_18 = new JButton("Pausar");
		btnNewButton_18.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pausar();
            }
        });
		panel_3.add(btnNewButton_18);
		
		panel_4 = new JPanel();
		panel_4.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "99% imposible ", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_4.setBackground(SystemColor.activeCaption);
		frame.getContentPane().add(panel_4, BorderLayout.CENTER);
		panel_4.setLayout(new GridLayout(4, 4, 10, 10));

	    for (int i = 0; i < 16; i++) {
	        botones[i] = new JButton();
	        int index = i;
	        botones[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    moverBoton(index);
                    verificarVictoria();
                }
            });
	        panel_4.add(botones[i]);
	    }
	    
	mezclarNumeros();    
	//random();
    actualizar();

}
	
	void reiniciarJuego() {
        mezclarNumeros();
        random();
        actualizar();
        segundos = 0;
        timer.setText("00:00");
        if (cronometro != null) {
            cronometro.cancel();
        }
        marcha = false;
        habilitarBotones(true);
    }
	
	void iniciar() {
        if (!marcha) {
            marcha = true;
            cronometro = new Timer();
            cronometro.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    segundos++;
                    int minutos = segundos / 60;
                    int segundosRestantes = segundos % 60;
                    timer.setText(String.format("%02d:%02d", minutos, segundosRestantes));
                }
            }, 0, 1000);
            habilitarBotones(true);
        }
    }

    void pausar() {
        if (marcha) {
            marcha = false;
            cronometro.cancel(); 
            habilitarBotones(false); 
        }
    }

    void habilitarBotones(boolean habilitar) {
        for (JButton boton : botones) {
            boton.setEnabled(habilitar);
        }
    }
	
	void moverBoton(int index) {
         int[] lados = verificarLados(espacioIndex);

        for (int i : lados) {
            if (index == i) {
                
                String temp = numeros[index];
                numeros[index] = numeros[espacioIndex];
                numeros[espacioIndex] = temp;

                espacioIndex = index;              
                actualizar();
                return;
            }
        }
    }

	int[] verificarLados(int index) {
	    
	    ArrayList<Integer> ladosValidos = new ArrayList<>();

	    //arriba
	    if (index - 4 >= 0) {
	        ladosValidos.add(index - 4);
	    }

	    // abajo
	    if (index + 4 < 16) {
	        ladosValidos.add(index + 4);
	    }

	    // izquierda
	    if (index % 4 != 0) {
	        ladosValidos.add(index - 1);
	    }

	    // derecha
	    if (index % 4 != 3) {
	        ladosValidos.add(index + 1);
	    }

	    int[] resultado = new int[ladosValidos.size()];
	    for (int i = 0; i < resultado.length; i++) {
	        resultado[i] = ladosValidos.get(i);
	    }

	    return resultado;
	}
    
	void actualizar() {
		for (int i = 0; i < 16; i++) {
            botones[i].setText(numeros[i]);
        }
	}
	
	void random() {
		Random rand = new Random();
        for (int i = numeros.length - 1; i > 0; i--) {
            int index = rand.nextInt(i + 1);
            String temp = numeros[index];
            numeros[index] = numeros[i];
            numeros[i] = temp;
        }
	}
	
	void mezclarNumeros() {
        numeros = new String[16];
        for (int i = 0; i < 16; i++) {
            numeros[i] = String.valueOf(i + 1);
        }
        numeros[15] = "";
    }
	
	void verificarVictoria() {
        boolean victoria = true;
        for (int i = 0; i < 15; i++) {
            if (!numeros[i].equals(String.valueOf(i + 1))) {
                victoria = false;
                break;
            }
        }

        if (victoria && numeros[15].equals("")) {
            
            JOptionPane.showMessageDialog(null, "Haz completado el juego 99% imposible\nMuy bien echo hermanito");
            pausar();
            habilitarBotones(false);
        }
    }
	
}

	
