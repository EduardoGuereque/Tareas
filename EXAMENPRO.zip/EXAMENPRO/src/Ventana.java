import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;

public class Ventana extends JFrame {

	    private JTextField textField;
	    private JTextField txtCalle;
	    private JTextField txtWerekeDeAnda;
	    private JTextField textField_3;
	    private JTable table_1;
	    private JTextField textField_1;

    public Ventana() {

    	setTitle(" ");
        setSize(700, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel2 = new JPanel();
        panel2.setLocation(400, 0);
        panel2.setLayout(new BorderLayout(0, 0));

        getContentPane().add(panel2, BorderLayout.CENTER);
        
        JLabel lblNewLabel = new JLabel("Factura en Java - [sin base de datos]");
        lblNewLabel.setOpaque(true);
        lblNewLabel.setBackground(SystemColor.activeCaption);
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 22));
        lblNewLabel.setForeground(SystemColor.controlLtHighlight);
        panel2.add(lblNewLabel, BorderLayout.NORTH);
        
        JPanel panel = new JPanel();
        panel2.add(panel, BorderLayout.CENTER);
        panel.setLayout(new GridLayout(5, 1, 50, 30));
        
        JPanel panel_1 = new JPanel();
        panel.add(panel_1);
        panel_1.setLayout(new BorderLayout(0, 0));
        
        JPanel panel_2 = new JPanel();
        panel_2.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Datos del cliente", TitledBorder.LEFT, TitledBorder.TOP, null, new Color(0, 0, 0)));
        panel_1.add(panel_2, BorderLayout.CENTER);
        panel_2.setLayout(new GridLayout(2, 6, 20, 20));
        
        JLabel lblNewLabel_2 = new JLabel("Documento:");
        lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
        panel_2.add(lblNewLabel_2);
        
        textField = new JTextField();
        textField.setText("123456");
        panel_2.add(textField);
        textField.setColumns(10);
        
        JLabel lblNewLabel_3 = new JLabel("Nombres:");
        lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
        panel_2.add(lblNewLabel_3);
        
        txtWerekeDeAnda = new JTextField();
        txtWerekeDeAnda.setText("wereke de anda");
        panel_2.add(txtWerekeDeAnda);
        txtWerekeDeAnda.setColumns(10);
        
        JLabel lblNewLabel_4 = new JLabel("Direccion:");
        lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
        panel_2.add(lblNewLabel_4);
        
        txtCalle = new JTextField();
        txtCalle.setText("Calle 1 #123");
        panel_2.add(txtCalle);
        txtCalle.setColumns(10);
        
        JLabel lblNewLabel_5 = new JLabel("Telefono:");
        lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
        panel_2.add(lblNewLabel_5);
        
        textField_3 = new JTextField();
        textField_3.setText("6121395851");
        panel_2.add(textField_3);
        textField_3.setColumns(10);
        
        JPanel panel_3 = new JPanel();
        panel_3.setBorder(new TitledBorder(null, "Datos de factura", TitledBorder.LEADING, TitledBorder.TOP, null, null));
        panel.add(panel_3);
        panel_3.setLayout(new BorderLayout(0, 0));
        
        JPanel panel_4 = new JPanel();
        panel_3.add(panel_4, BorderLayout.CENTER);
        panel_4.setLayout(new GridLayout(1, 4, 0, 0));
        
        JLabel lblNewLabel_7 = new JLabel("No. factura: ");
        lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
        panel_4.add(lblNewLabel_7);
        
        JLabel lblNewLabel_8 = new JLabel("1");
        lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 13));
        panel_4.add(lblNewLabel_8);
        
        JLabel lblNewLabel_9 = new JLabel("Fecha:");
        lblNewLabel_9.setHorizontalAlignment(SwingConstants.CENTER);
        panel_4.add(lblNewLabel_9);
        
        JLabel lblNewLabel_10 = new JLabel("17/03/2025");
        lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD, 13));
        panel_4.add(lblNewLabel_10);
        
        JPanel panel_5 = new JPanel();
        panel_5.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
        panel.add(panel_5);
        panel_5.setLayout(null);
        
        JLabel lblVerListadoDe = new JLabel("Ver listado de facturas");
        lblVerListadoDe.setBounds(36, 11, 148, 59);
        panel_5.add(lblVerListadoDe);
        
        JButton btnNewButton = new JButton("Añadir");
        btnNewButton.setBackground(new Color(154, 205, 50));
        btnNewButton.setBounds(455, 11, 89, 59);
        panel_5.add(btnNewButton);
        
        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBackground(new Color(220, 20, 60));
        btnEliminar.setBounds(570, 11, 89, 59);
        panel_5.add(btnEliminar);
        
        JPanel panel_6 = new JPanel();
        panel_6.setBounds(new Rectangle(0, 0, 50, 0));
        panel.add(panel_6);
        panel_6.setLayout(new GridLayout(0, 1, 0, 0));
        
        table_1 = new JTable();
        table_1.setModel(new DefaultTableModel(
        	new Object[][] {
        		{"Producto", "Cantidad", "Valor", "Sub Total"},
        		{"agua", "2", "500", "1000.0"},
        		{"cereal", "5", "1000", "5000.0"},
        		{"leche", "2", "300", "600.0"},
        		{"manzana", "4", "250", "1000.0"},
        	},
        	new String[] {
        		"New column", "New column", "New column", "New column"
        	}
        ));
        panel_6.add(table_1);
        
        JPanel panel_7 = new JPanel();
        panel.add(panel_7);
        panel_7.setLayout(new BorderLayout(0, 0));
        
        JPanel panel_8 = new JPanel();
        panel_7.add(panel_8, BorderLayout.CENTER);
        panel_8.setLayout(null);
        
        JLabel lblNewLabel_1 = new JLabel("SubTotal:");
        lblNewLabel_1.setBounds(10, 0, 49, 14);
        panel_8.add(lblNewLabel_1);
        
        JLabel lblNewLabel_1_1 = new JLabel("Descuento:");
        lblNewLabel_1_1.setBounds(10, 25, 60, 14);
        panel_8.add(lblNewLabel_1_1);
        
        JLabel lblNewLabel_1_2 = new JLabel("IVA:");
        lblNewLabel_1_2.setBounds(10, 50, 49, 14);
        panel_8.add(lblNewLabel_1_2);
        
        JLabel lblNewLabel_1_3 = new JLabel("Total:");
        lblNewLabel_1_3.setBounds(10, 75, 49, 14);
        panel_8.add(lblNewLabel_1_3);
        
        JLabel lblNewLabel_1_4 = new JLabel("7600.0");
        lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1_4.setBounds(72, 0, 49, 14);
        panel_8.add(lblNewLabel_1_4);
        
        JLabel lblNewLabel_1_2_1 = new JLabel("1371.8");
        lblNewLabel_1_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1_2_1.setBounds(72, 50, 49, 14);
        panel_8.add(lblNewLabel_1_2_1);
        
        textField_1 = new JTextField();
        textField_1.setText("5");
        textField_1.setBounds(72, 25, 49, 20);
        panel_8.add(textField_1);
        textField_1.setColumns(10);
        
        JLabel lblNewLabel_1_3_2 = new JLabel("8971.8");
        lblNewLabel_1_3_2.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1_3_2.setBounds(72, 75, 49, 14);
        panel_8.add(lblNewLabel_1_3_2);
        
        JCheckBox chckbxNewCheckBox = new JCheckBox("");
        chckbxNewCheckBox.setSelected(true);
        chckbxNewCheckBox.setBounds(133, 20, 27, 23);
        panel_8.add(chckbxNewCheckBox);
        
        JLabel lblNewLabel_1_1_1 = new JLabel("Valor:");
        lblNewLabel_1_1_1.setBounds(166, 25, 49, 14);
        panel_8.add(lblNewLabel_1_1_1);
        
        JLabel lblNewLabel_1_1_2 = new JLabel("380.0");
        lblNewLabel_1_1_2.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1_1_2.setBounds(232, 25, 49, 14);
        panel_8.add(lblNewLabel_1_1_2);
        
        JButton btnNewButton_1 = new JButton("Limpiar");
        btnNewButton_1.setBounds(587, 80, 89, 23);
        panel_8.add(btnNewButton_1);
        
        JButton btnNewButton_1_1 = new JButton("Finalizar Factura");
        btnNewButton_1_1.setBounds(439, 80, 138, 23);
        panel_8.add(btnNewButton_1_1);
    }
}
